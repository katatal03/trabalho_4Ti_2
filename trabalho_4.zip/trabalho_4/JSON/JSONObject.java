//package org.json.simple;

public class JSONObject {

	public void put(String string, double d) {
		// TODO Auto-generated method stub
		
	}

	public void put(String string, String string2) {
		// TODO Auto-generated method stub
		
	}

	public JSONArray get(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object[] keySet() {
		// TODO Auto-generated method stub
		return null;
	}

}