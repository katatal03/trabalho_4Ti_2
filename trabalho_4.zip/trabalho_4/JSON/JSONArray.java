//package org.json.simple;

public class JSONArray {

	public void add(JSONObject item) {
		
		
	}

}